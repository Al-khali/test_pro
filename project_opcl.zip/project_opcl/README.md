# PROJET2-OC

Deuxième projet du parcours DEVELOPPEUR chez OpenClassrooms. Créer un prototype de site en intégrant la maquette conçue par le designer UI, en HTML et CSS. Le site doit bien sûr être responsive.
